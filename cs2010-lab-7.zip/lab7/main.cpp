#include <iostream>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <tuple>
#include <iomanip>
#include <functional>
#include <algorithm>
#include <fstream>



struct funcObj {
    bool operator()(const std::string& a, const std::string& b) {
        return a.length() < b.length();
    }
};

using WORD = std::string;
using WORD_LIST = std::set<WORD>;
using WORD_FREQ_LIST = std::map<char, int>;
using FREQ_WORD_LIST = std::multimap<int, WORD>;
using COUNTER = std::tuple<int, int, int>;
using LONGEST = std::priority_queue<WORD, std::vector<WORD>, funcObj>;

struct DICTION {
    COUNTER stats;
    WORD_LIST words;
    WORD_FREQ_LIST wordFreq;
    FREQ_WORD_LIST freqWord;
    LONGEST longWord;
    std::map<WORD, int> wordCount;
};

WORD getNextWord(DICTION &d) {
    WORD w;
    char ch;
    bool inWord = false;
    std::cin.get(ch);
    while(!std::cin.eof()) {
        if (isalpha(ch)) {
            w.push_back(ch);
            inWord = true;
        }
        else if (inWord) return w;
        std::cin.get(ch);
    }
    return w;
}

void processFile(DICTION &d) {
    int letters = 0, words = 0, lines = 1;  // Start with 1 line
    char ch;
   
    // Count lines and letters
    while (std::cin.get(ch)) {
        letters++;
        if (ch == '\n') lines++;
    }
   
    // Reset cin to beginning
    std::cin.clear();
    std::cin.seekg(0);
   
    // Process words
    WORD word;
    while (!(word = getNextWord(d)).empty()) {
        d.words.insert(word);
        d.wordCount[word]++;
        d.longWord.push(word);
        words++;
       
        // Count letter frequencies
        for (char c : word) {
            d.wordFreq[c]++;
        }
    }
   
    // Build frequency-word multimap
    for (const auto& pair : d.wordCount) {
        d.freqWord.insert({pair.second, pair.first});
    }
   
    d.stats = std::make_tuple(letters, words, lines);
}

void displayResults(const DICTION &d) {
    // Display dictionary words
    std::cout << "Words in dictionary: ";
    for (const auto& word : d.words) {
        std::cout << word << ",";
    }
    std::cout << "\n\n";
   
    // Display counts
    std::cout << "Number of Letters : " << std::get<0>(d.stats) << "\n";
    std::cout << "Number of Words  : " << std::get<1>(d.stats) << "\n";
    std::cout << "Number of Lines  : " << std::get<2>(d.stats) << "\n\n";
   
    // Display letter frequencies
    std::cout << "/--------------\\\n";
    std::cout << "| Letter Freq |\n";
    std::cout << "\\--------------/\n";
   
    // First uppercase letters
    for (char c = 'A'; c <= 'Z'; c++) {
        std::cout << "[" << c << "] | ";
        int freq = d.wordFreq.count(c) ? d.wordFreq.at(c) : 0;
        int stars = std::min(freq, 10);
        for (int i = 0; i < stars; i++) {
            std::cout << "*";
        }
        if (freq > 10) {
            std::cout << " (" << freq - 10 << ")";
        }
        std::cout << "\n";
    }

    // Then lowercase letters
    for (char c = 'a'; c <= 'z'; c++) {
        std::cout << "[" << c << "] | ";
        int freq = d.wordFreq.count(c) ? d.wordFreq.at(c) : 0;
        int stars = std::min(freq, 10);
        for (int i = 0; i < stars; i++) {
            std::cout << "*";
        }
        if (freq > 10) {
            std::cout << " (" << freq - 10 << ")";
        }
        std::cout << "\n";
    }
    std::cout << "\n";
   
    // Display word frequencies
    std::cout << "/------------\\\n";
    std::cout << "| Dictionary |\n";
    std::cout << "\\------------/\n";
    std::cout << "Word Frequency\n";
    std::cout << "-------------------------\n";
    for (const auto& word : d.words) {
        std::cout << std::left << std::setw(15) << word << d.wordCount.at(word) << "\n";
    }
    std::cout << "\n";
   
    // Display histogram
    std::cout << "/------------\\\n";
    std::cout << "| Histogram |\n";
    std::cout << "\\------------/\n";

    // Find max frequency for histogram height
    int maxFreq = 0;
    for (const auto& pair : d.wordCount) {
        maxFreq = std::max(maxFreq, pair.second);
    }

    // Print stars
    for (int level = maxFreq; level > 0; level--) {
        std::cout << "           ";
        for (const auto& word : d.words) {
            if (d.wordCount.at(word) >= level) {
                std::cout << "*   ";
            } else {
                std::cout << "    ";
            }
        }
        std::cout << "\n";
    }

    // Print baseline
    std::cout << "---------------\n";
    std::cout << "        ";
    for (size_t i = 0; i < d.words.size(); i++) {
      //  std::cout << "^";
    }
    std::cout << "\n";

    // Print word labels with frequency bars
    for (const auto& word : d.words) {
        std::cout << word << std::string(6 - word.length(), '-') << "/";
        for (int i = 0; i < d.wordCount.at(word); i++) {
            std::cout << "|";
        }
        std::cout << "\n";
    }

    // Display longest word
    LONGEST tempQueue = d.longWord;
    if (!tempQueue.empty()) {
        std::cout << "\nLongest Word is : " << tempQueue.top() << "\n";
    }
}

int main() {
    std::ifstream inputFile("letter.txt");
    if (!inputFile.is_open()) {
        std::cerr << "Error opening file!" << std::endl;
        return 1;
    }

    DICTION dictionary;
    
    // Pass input file stream to processFile
    std::cin.rdbuf(inputFile.rdbuf()); // Redirect std::cin to the file
    processFile(dictionary);           // Process the content of the file

    inputFile.close(); // Close the file
    displayResults(dictionary); // Display the results

    return 0;
}


